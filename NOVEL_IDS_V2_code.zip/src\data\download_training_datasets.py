
# STEP 17: DOWNLOAD UNSW-NB15 AND NSL-KDD

import argparse
from pathlib import Path

from src.data.source_manager import (
    load_dataset_sources,
    download_csv,
    calculate_file_hash
)


def download_training_datasets(cache_dir):
    cache_dir = Path(cache_dir)
    sources = load_dataset_sources()

    datasets = {
        "UNSW-NB15": {
            "training": "UNSW_NB15_training-set.csv",
            "testing": "UNSW_NB15_testing-set.csv"
        },
        "NSL-KDD": {
            "training": "KDDTrain+.csv",
            "testing": "KDDTest+.csv"
        }
    }

    print("========== STEP 17: TRAINING DATA DOWNLOAD ==========")

    for dataset_name, files in datasets.items():
        print(f"\n{dataset_name}")

        for split, filename in files.items():
            url = sources[dataset_name][split]
            destination = cache_dir / dataset_name / filename

            if destination.exists() and destination.stat().st_size > 0:
                print(f"Already available: {filename}")
            else:
                print(f"Downloading: {filename}")
                download_csv(url, destination)

            size_mb = destination.stat().st_size / (1024 * 1024)
            file_hash = calculate_file_hash(destination)

            print(f"Size: {size_mb:.2f} MB")
            print(f"SHA-256: {file_hash}")

    print("\nTraining dataset downloads verified.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cache-dir",
        required=True,
        help="Directory where downloaded datasets will be stored"
    )

    args = parser.parse_args()
    download_training_datasets(args.cache_dir)
